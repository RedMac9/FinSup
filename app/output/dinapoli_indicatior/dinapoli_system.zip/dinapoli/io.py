"""Wczytywanie notowań.

Obsługuje formaty, na które najłatwiej trafić przy polskich danych:
Stooq, pliki Bossa/Metastock oraz dowolny CSV z kolumnami OHLC.
"""

from typing import Optional

import pandas as pd

_ALIASES = {
    "date": "date", "data": "date", "<date>": "date", "datetime": "date",
    "time": "date", "timestamp": "date",
    "open": "open", "otwarcie": "open", "<open>": "open",
    "high": "high", "najwyzszy": "high", "najwyższy": "high", "<high>": "high",
    "low": "low", "najnizszy": "low", "najniższy": "low", "<low>": "low",
    "close": "close", "zamkniecie": "close", "zamknięcie": "close",
    "<close>": "close", "adj close": "close",
    "volume": "volume", "wolumen": "volume", "<vol>": "volume",
    "obrot": "volume", "obrót": "volume",
}


def load_csv(path: str, date_col: Optional[str] = None,
             dayfirst: bool = False) -> pd.DataFrame:
    """Wczytuje CSV i zwraca ramkę gotową dla Analyzera.

    Sam wykrywa separator, nazwy kolumn (PL/EN, ze znacznikami <> z Bossy)
    i ustawia DatetimeIndex.
    """
    df = pd.read_csv(path, sep=None, engine="python")
    df.columns = [_ALIASES.get(str(c).strip().lower(), str(c).strip().lower())
                  for c in df.columns]

    dc = date_col or ("date" if "date" in df.columns else df.columns[0])
    df[dc] = pd.to_datetime(df[dc], dayfirst=dayfirst, format="mixed")
    df = df.set_index(dc).sort_index()

    missing = {"open", "high", "low", "close"} - set(df.columns)
    if missing:
        raise ValueError(f"Brak kolumn {missing}. Znalezione: {list(df.columns)}")

    keep = [c for c in ("open", "high", "low", "close", "volume") if c in df.columns]
    out = df[keep].astype(float)
    return out[~out.index.duplicated(keep="last")].dropna(subset=["close"])


def to_frame(records) -> pd.DataFrame:
    """Lista dictów / krotek -> ramka OHLCV. Przydatne przy danych z API."""
    df = pd.DataFrame(records)
    df.columns = [_ALIASES.get(str(c).lower(), str(c).lower()) for c in df.columns]
    df["date"] = pd.to_datetime(df["date"])
    return df.set_index("date").sort_index()
