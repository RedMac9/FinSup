"""Demo: pełen przepływ na jednym instrumencie.

    python -m dinapoli.demo                # dane syntetyczne
    python -m dinapoli.demo dane.csv KGH   # własny plik
"""

import sys

import numpy as np
import pandas as pd

from . import backtest, plotting
from .config import Config
from .io import load_csv
from .system import Analyzer


def synthetic(n: int = 900, seed: int = 7) -> pd.DataFrame:
    """Dane zastępcze - do sprawdzenia, czy wszystko się spina."""
    rng = np.random.default_rng(seed)
    t = np.arange(n)
    cyc = 0.06 * np.sin(t / 38) + 0.035 * np.sin(t / 13 + 1)
    ret = 0.0004 + np.diff(np.r_[0, cyc]) + rng.normal(0, 0.011, n)
    close = 100 * np.exp(np.cumsum(ret))
    op = np.r_[close[0], close[:-1]] * (1 + rng.normal(0, 0.002, n))
    hi = close * (1 + np.abs(rng.normal(0, 0.006, n)))
    lo = close * (1 - np.abs(rng.normal(0, 0.006, n)))
    return pd.DataFrame({
        "open": op,
        "high": np.maximum.reduce([op, hi, close]),
        "low": np.minimum.reduce([op, lo, close]),
        "close": close,
        "volume": rng.integers(1e5, 9e5, n),
    }, index=pd.bdate_range("2023-01-02", periods=n))


def main():
    if len(sys.argv) > 1:
        df = load_csv(sys.argv[1])
        symbol = sys.argv[2] if len(sys.argv) > 2 else "?"
    else:
        df, symbol = synthetic(), "SYNTETYK"
        print("Brak pliku - lece na danych syntetycznych.\n"
              "Wyniki backtestu na szumie nie znacza NIC. To smoke test.\n")

    a = Analyzer(df, Config(), symbol=symbol)

    print(a.snapshot().report())
    print()

    sig = a.signal()
    print("Sygnal na dzis:", sig.describe() if sig else "brak")
    print()

    signals = a.scan(start=min(300, len(df) // 3))
    print(f"Sygnalow historycznych: {len(signals)}")

    for target in ("COP", "OP"):
        trades = backtest.run(a, signals, target=target)
        print(f"\n--- wyjscie na {target} ---")
        print(backtest.stats(trades).to_string())
        d = backtest.by_setup(trades)
        if not d.empty:
            print(d.to_string())

    path = plotting.plot(a, signals=signals, bars=300, max_zones=8,
                         path=f"{symbol}_chart.png")
    print(f"\nWykres: {path}")


if __name__ == "__main__":
    main()
