"""Rysowanie wykresu w stylu oryginału z dokumentu.

Świece, przesunięte średnie, poziomy Fibo cienkimi liniami, strefy Zgodności
jako prostokąty o intensywności zależnej od siły, MacdPred jako linia
wsparcia/oporu, sygnały ze znacznikiem SL.
"""

from typing import List, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Rectangle

from .system import Analyzer, Signal, Snapshot

COL = {
    "up": "#ffffff", "dn": "#1a1a1a", "wick": "#1a1a1a",
    "dma_fast": "#c0392b", "dma_slow": "#27ae60",
    "ma50": "#2b6cb0", "ma100": "#27ae60", "ma200": "#b8860b",
    "pred": "#8e44ad",
    "zone_sup": "#2e8b57", "zone_res": "#c0392b",
    "ret": "#7f8c8d", "exp": "#2980b9",
    "long": "#1e8449", "short": "#922b21", "sl": "#e74c3c",
}


def _candles(ax, d: pd.DataFrame):
    x = mdates.date2num(d.index.to_pydatetime())
    w = 0.6 * (np.median(np.diff(x)) if len(x) > 1 else 1)
    up = d["close"] >= d["open"]
    ax.vlines(x, d["low"], d["high"], color=COL["wick"], linewidth=0.6, zorder=2)
    for mask, face in ((up, COL["up"]), (~up, COL["dn"])):
        if not mask.any():
            continue
        xs = x[mask.to_numpy()]
        lo = np.minimum(d["open"][mask], d["close"][mask])
        hi = np.maximum(d["open"][mask], d["close"][mask])
        h = np.maximum(hi - lo, 1e-9)
        for xi, li, hi_ in zip(xs, lo, h):
            ax.add_patch(Rectangle((xi - w / 2, li), w, hi_, facecolor=face,
                                   edgecolor=COL["wick"], linewidth=0.6, zorder=3))


def plot(analyzer: Analyzer, snap: Optional[Snapshot] = None,
         bars: int = 260, signals: Optional[List[Signal]] = None,
         show_levels: bool = True, path: str = "chart.png",
         title: Optional[str] = None, max_zones: int = 10,
         min_strength: float = 0.0, figsize=(18, 9), dpi=110):
    """Zapisuje wykres do pliku PNG."""
    snap = snap or analyzer.snapshot()
    df = analyzer.df
    i = snap.idx
    d = df.iloc[max(0, i - bars + 1): i + 1]

    fig, (ax, ax2) = plt.subplots(
        2, 1, figsize=figsize, dpi=dpi, sharex=True,
        gridspec_kw={"height_ratios": [4, 1], "hspace": 0.04})
    fig.patch.set_facecolor("white")
    ax.set_facecolor("white")

    _candles(ax, d)

    for key, lbl, lw in (("dma_fast", "DMA 3x3", 1.0),
                         ("dma_slow", "DMA 25x5", 1.2),
                         ("ma50", "MA 50", 1.0),
                         ("ma100", "MA 100", 1.0),
                         ("ma200", "MA 200", 1.2)):
        if key in d and d[key].notna().any():
            ax.plot(d.index, d[key], color=COL.get(key, "#888"),
                    linewidth=lw, label=lbl, zorder=4)

    if "macd_pred" in d:
        ax.plot(d.index, d["macd_pred"], color=COL["pred"], linewidth=0.9,
                linestyle=(0, (4, 2)), label="MacdPred", zorder=4)

    lo_v, hi_v = d["low"].min(), d["high"].max()
    pad = (hi_v - lo_v) * 0.12
    ax.set_ylim(lo_v - pad, hi_v + pad)

    # pojedyncze poziomy Fibo - tło
    if show_levels:
        for lv in snap.levels:
            if not (lo_v - pad <= lv.price <= hi_v + pad):
                continue
            c = COL["exp"] if lv.kind == "expansion" else COL["ret"]
            ax.axhline(lv.price, color=c, linewidth=0.4, alpha=0.25, zorder=1)

    # strefy Zgodności
    x0, x1 = d.index[0], d.index[-1]
    visible = [z for z in snap.zones
               if lo_v - pad <= z.mid <= hi_v + pad and z.strength >= min_strength]
    visible.sort(key=lambda z: -z.strength)
    for z in visible[:max_zones]:
        c = COL["zone_sup"] if z.direction == "support" else COL["zone_res"]
        alpha = min(0.10 + 0.05 * z.count, 0.38)
        h = max(z.width, (hi_v - lo_v) * 0.0035)
        ax.add_patch(Rectangle((mdates.date2num(x0), z.low),
                               mdates.date2num(x1) - mdates.date2num(x0), h,
                               facecolor=c, alpha=alpha, edgecolor=c,
                               linewidth=0.7, zorder=1))
        ax.annotate(f"{z.grade[:4]} {z.names} [{z.strength}]",
                    xy=(mdates.date2num(x1), z.mid), xytext=(4, 0),
                    textcoords="offset points", fontsize=6.5, color=c,
                    va="center", zorder=6)

    # sygnały
    for s in (signals or []):
        if s.idx < d.index.size and df.index[s.idx] < x0:
            continue
        if df.index[s.idx] < x0:
            continue
        dt = df.index[s.idx]
        c = COL["long"] if s.side == "long" else COL["short"]
        m = "^" if s.side == "long" else "v"
        ax.scatter([dt], [s.entry], marker=m, s=90, color=c, zorder=7,
                   edgecolor="black", linewidth=0.5)
        ax.annotate(s.setup, xy=(dt, s.entry), xytext=(0, 12 if s.side == "long" else -16),
                    textcoords="offset points", fontsize=7, color=c,
                    ha="center", zorder=7)
        ax.hlines(s.sl, dt, x1, color=COL["sl"], linewidth=0.8,
                  linestyle=":", zorder=6)

    ax.set_title(title or f"{analyzer.symbol} - {snap.date:%Y-%m-%d}  "
                          f"trend D/W/M: {snap.trend['D']}/{snap.trend['W']}/"
                          f"{snap.trend['M']}  ({snap.context})",
                 loc="left", fontsize=10)
    ax.legend(loc="upper left", fontsize=7, ncol=6, framealpha=0.9)
    ax.grid(alpha=0.15, linewidth=0.5)
    ax.yaxis.tick_right()

    # panel dolny: oscylator zdetrendowany z pasmami
    if "detrended" in d:
        ax2.fill_between(d.index, d["detrended"], 0,
                         where=d["detrended"] >= 0, color="#27ae60", alpha=0.35)
        ax2.fill_between(d.index, d["detrended"], 0,
                         where=d["detrended"] < 0, color="#c0392b", alpha=0.35)
        ax2.axhline(0, color="#555", linewidth=0.6)
        ax2.set_ylabel("Detrended", fontsize=7)
    ax2.grid(alpha=0.15, linewidth=0.5)
    ax2.yaxis.tick_right()
    ax2.xaxis.set_major_locator(mdates.AutoDateLocator())
    ax2.xaxis.set_major_formatter(mdates.ConciseDateFormatter(
        mdates.AutoDateLocator()))

    for a in (ax, ax2):
        for sp in a.spines.values():
            sp.set_linewidth(0.6)

    fig.savefig(path, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return path
