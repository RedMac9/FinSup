"""Backtest zdarzeniowy.

Celowo minimalny: jedna pozycja naraz, wejście po cenie zamknięcia świecy
sygnału, wyjście na SL albo na zasięgu. Chodzi o sanity check reguł,
nie o symulację rachunku maklerskiego - nie ma tu poślizgu, prowizji
ani realistycznego wypełnienia zleceń.
"""

from dataclasses import dataclass
from typing import List, Optional

import numpy as np
import pandas as pd

from .system import Analyzer, Signal


@dataclass
class Trade:
    entry_date: pd.Timestamp
    exit_date: pd.Timestamp
    side: str
    setup: str
    entry: float
    exit: float
    sl: float
    target: float
    reason: str
    bars: int

    @property
    def pnl_pct(self) -> float:
        r = (self.exit - self.entry) / self.entry
        return r * 100 if self.side == "long" else -r * 100

    @property
    def r_multiple(self) -> float:
        risk = abs(self.entry - self.sl)
        if risk == 0:
            return 0.0
        move = (self.exit - self.entry) if self.side == "long" else (self.entry - self.exit)
        return move / risk


def run(analyzer: Analyzer, signals: List[Signal], target: str = "COP",
        max_bars: int = 60, trail_atr: Optional[float] = None) -> List[Trade]:
    """trail_atr - jeśli podane, SL podąża za ceną w odległości N x ATR.
    Odpowiednik "zacieśniam SL" z dokumentu źródłowego."""
    df = analyzer.df
    trades: List[Trade] = []
    busy_until = -1

    for sig in signals:
        if sig.idx <= busy_until:
            continue
        tgt = sig.targets.get(target) or list(sig.targets.values())[0]
        entry = sig.entry
        exit_price, exit_i, reason = None, None, "timeout"

        stop = sig.sl
        for j in range(sig.idx + 1, min(sig.idx + 1 + max_bars, len(df))):
            hi, lo = df["high"].iloc[j], df["low"].iloc[j]
            if sig.side == "long":
                if lo <= stop:
                    exit_price, exit_i, reason = stop, j, "SL"
                    break
                if hi >= tgt:
                    exit_price, exit_i, reason = tgt, j, target
                    break
            else:
                if hi >= stop:
                    exit_price, exit_i, reason = stop, j, "SL"
                    break
                if lo <= tgt:
                    exit_price, exit_i, reason = tgt, j, target
                    break

            if trail_atr:
                a_v = df["atr"].iloc[j]
                if sig.side == "long":
                    stop = max(stop, float(df["close"].iloc[j]) - trail_atr * a_v)
                else:
                    stop = min(stop, float(df["close"].iloc[j]) + trail_atr * a_v)

        if exit_price is None:
            exit_i = min(sig.idx + max_bars, len(df) - 1)
            exit_price = float(df["close"].iloc[exit_i])

        trades.append(Trade(
            entry_date=sig.date, exit_date=df.index[exit_i], side=sig.side,
            setup=sig.setup, entry=entry, exit=float(exit_price), sl=sig.sl,
            target=float(tgt), reason=reason, bars=exit_i - sig.idx))
        busy_until = exit_i

    return trades


def stats(trades: List[Trade]) -> pd.Series:
    if not trades:
        return pd.Series(dtype=float)
    r = np.array([t.r_multiple for t in trades])
    p = np.array([t.pnl_pct for t in trades])
    wins = r > 0
    return pd.Series({
        "transakcji": len(trades),
        "trafnosc_%": round(100 * wins.mean(), 1),
        "suma_R": round(r.sum(), 2),
        "srednie_R": round(r.mean(), 3),
        "mediana_R": round(float(np.median(r)), 3),
        "srednia_wygrana_R": round(r[wins].mean(), 2) if wins.any() else 0.0,
        "srednia_strata_R": round(r[~wins].mean(), 2) if (~wins).any() else 0.0,
        "suma_pnl_%": round(p.sum(), 2),
        "sr_dlugosc_swiec": round(np.mean([t.bars for t in trades]), 1),
    })


def by_setup(trades: List[Trade]) -> pd.DataFrame:
    if not trades:
        return pd.DataFrame()
    rows = [{"setup": t.setup, "R": t.r_multiple, "win": t.r_multiple > 0}
            for t in trades]
    d = pd.DataFrame(rows)
    return d.groupby("setup").agg(
        n=("R", "size"), suma_R=("R", "sum"), srednie_R=("R", "mean"),
        trafnosc=("win", "mean")).round(3).sort_values("suma_R", ascending=False)
